function SetBookList(data){

    RedoFunction_When_Fail_ToNotShowMsg_Used = undefined;

    $('[data-booklist]').empty();

    if (typeof(data.TotalPage) != 'undefined'){
        Oddi_SetAndUpdatePaginationBar(data.TotalPage,'[data-pagination-bar]','',data.Pagnation + 1 , 'BooksListLoad()');
    }

    $('#list').empty();

    for (var i = 0; i < data.data.length; i++) {

        // 列表物件容器
        let CoverListItemContainer_liTag = document.createElement('li');
        CoverListItemContainer_liTag.className = 'odd-border-block-style odd-round w3-white';

        let CoverListItemContainer_divTag = document.createElement('div');
        CoverListItemContainer_divTag.className = 'odd-books-list-block-head';
        CoverListItemContainer_divTag.dataset.bookListItem = data.data[i][4];
        CoverListItemContainer_divTag.style.cursor = 'pointer';
        CoverListItemContainer_liTag.appendChild(CoverListItemContainer_divTag);

        // 列表物件排版容器
        let CoverListItemLayoutContainer_divTag = document.createElement('div');
        CoverListItemLayoutContainer_divTag.className = 'odd-iread-bookcover ';
        // CoverListItemLayoutContainer_divTag.style.width = '80%';

        // 封面圖
        let CoverListItemCover_imgTag = document.createElement('img');
        CoverListItemCover_imgTag.className = 'w3-image odd-round w3-card ';
        CoverListItemCover_imgTag.alt = '{0}-圖書封面圖'.format(data.data[i][1]);
        try {
            CoverListItemCover_imgTag.src = SystemsUrl['iReadDataManage']['URL'] + data.data[i][3][0][3].substr(1);
        } catch (e) {
            CoverListItemCover_imgTag.src = '#';
        }
        CoverListItemLayoutContainer_divTag.appendChild(CoverListItemCover_imgTag);
        CoverListItemContainer_divTag.appendChild(CoverListItemLayoutContainer_divTag);


        let CoverListbody_divTag = document.createElement('div');
        CoverListbody_divTag.className = 'odd-block';
        CoverListItemContainer_divTag.appendChild(CoverListbody_divTag);
        // 書名
        let CoverListItemTitle_divTag = document.createElement('div');
        let CoverListItemTitle_ulTag = document.createElement('ul');
        let CoverListItemTitle_liTag = document.createElement('li');
        let CoverListItemTitle_pTag = document.createElement('span');
        CoverListItemTitle_divTag.className = 'odd-tags-function-block-defult';
        CoverListItemTitle_ulTag.className = 'odd-tags-function-ul';
        CoverListItemTitle_liTag.className = 'odd-tags-function-items';
        CoverListItemTitle_pTag.className = 'odd-text-odd-darkblue odd-fontweight-b odd-large';

        CoverListItemTitle_pTag.textContent = data.data[i][1];
        CoverListItemTitle_liTag.appendChild(CoverListItemTitle_pTag);
        CoverListItemTitle_ulTag.appendChild(CoverListItemTitle_liTag);
        CoverListItemTitle_divTag.appendChild(CoverListItemTitle_ulTag)
        CoverListbody_divTag.appendChild(CoverListItemTitle_divTag);

        // 喜閱幣
        let CoverListItemPrice_divTag = document.createElement('div');
        let CoverListItemPrice_ulTag = document.createElement('ul');
        let CoverListItemPrice_liTag = document.createElement('li');
        let CoverListItemPrice_spanTag = document.createElement('span');

        CoverListItemPrice_divTag.className = 'odd-tags-function-block-defult';
        CoverListItemPrice_ulTag.className = 'odd-tags-function-ul';
        CoverListItemPrice_liTag.className = 'odd-tags-function-items';
        CoverListItemPrice_spanTag.className = 'odd-text-red odd-small';

        CoverListItemPrice_spanTag.textContent = '喜閱幣：{0} '.format(data.data[i][2]);
        CoverListItemPrice_liTag.appendChild(CoverListItemPrice_spanTag);
        CoverListItemPrice_ulTag.appendChild(CoverListItemPrice_liTag);
        CoverListItemPrice_divTag.appendChild(CoverListItemPrice_ulTag);
        // CoverListItemLayoutContainer_divTag.appendChild(CoverListItemPrice_divTag);

        CoverListbody_divTag.appendChild(CoverListItemPrice_divTag);

        // 色點
        let BookColor_divTag = document.createElement('div');
        let BookColor_ulTag = document.createElement('ul');
        let BookColor_liTag = document.createElement('li');
        let BookColor_spanTag = document.createElement('span');
        BookColor_divTag.className = 'odd-tags-function-block-defult';
        BookColor_ulTag.className = 'odd-tags-function-ul';
        BookColor_liTag.className = 'odd-tags-function-items';
        BookColor_liTag.appendChild(document.createTextNode('色點：'));

        if (data.data[i][5]){
            BookColor_spanTag.className = 'odd-tags-circle-outline w3-{0}'.format(data.data[i][5][1]);
            BookColor_liTag.appendChild(BookColor_spanTag);
            BookColor_liTag.appendChild(document.createTextNode(data.data[i][5][0]));
        } else {
            BookColor_spanTag.textContent = '本圖書尚未設定色點';
            BookColor_liTag.appendChild(BookColor_spanTag);
        }
        BookColor_ulTag.appendChild(BookColor_liTag);
        BookColor_divTag.appendChild(BookColor_ulTag);

        CoverListbody_divTag.appendChild(BookColor_divTag);

        $('#list').append(CoverListItemContainer_liTag);
    }

    if (!data.data.length){
        $('#list').html('<span class="w3-text-grey">{0}<span>'.format(Msg['CoverListNoBookFound']));
    }

    $('[data-book-list-item]').on('click',function(){
        location.href = '{0}/book?a={1}'.format(hostplace,this.dataset.bookListItem);
    });

    location.href = '#list';
}

function RedoFunction_When_Fail_ToNotShowMsg_Used_WhenBooksListLoad(){
    BooksListLoad({'CleanPage':1});
}

function BooksListLoad(CurrentFilterData){
    CurrentFilterData = CurrentFilterData || {};

    for (let i = 0; i < $('[data-filter-dropdown-value]').length; i++) {
        CurrentFilterData[$('[data-filter-dropdown-value]')[i].dataset.filterDropdown] = $('[data-filter-dropdown-value]')[i].dataset.filterDropdownValue;
    }

    for (var i = 0; i < $('[data-filter-input]').length; i++) {
        CurrentFilterData[$('[data-filter-input]')[i].dataset.filterInput] = $('[data-filter-input]')[i].value;
    }

    CurrentFilterData['PageRows'] = $('[data-pagenation-perpageamount]').val();

    CurrentFilterData['Pagnation'] = parseInt($('[data-pagination-bar] [data-pagination-item-current]').attr('data-pagination-item'));

    !RedoFunction_When_Fail_ToNotShowMsg_Used ? RedoFunction_When_Fail_ToNotShowMsg_Used = RedoFunction_When_Fail_ToNotShowMsg_Used_WhenBooksListLoad : false;

    ajaxCallServerPost('/getbooklistdata', null, CurrentFilterData, SetBookList, 0);
}

function Oddi_DownloadBooksList(DownloadMode){
    let FilterData = {};

    switch (DownloadMode){
        case 'filter':

            for (let i = 0; i < $('[data-filter-dropdown-value]').length; i++) {
                FilterData[$('[data-filter-dropdown-value]')[i].dataset.filterDropdown] = $('[data-filter-dropdown-value]')[i].dataset.filterDropdownValue;
            }

            for (var i = 0; i < $('[data-filter-input]').length; i++) {
                FilterData[$('[data-filter-input]')[i].dataset.filterInput] = $('[data-filter-input]')[i].value;
            }
            break;

        case "all":
            break;

        default:
            return false;
    }

    ajaxCallServerPost('/bookslistexport','',FilterData,function(data){
        try {
            Oddi_ImportReportDownload(data.data,0);
        } catch (e) {
            $.getScript('/oddi_lib/js/Oddi/OddiTools/OddiTools_DOMProcess.js{0}'.format(CacheEliminator));

            let GetObjTimerId = setInterval(function(){
                try {
                    Oddi_ImportReportDownload(data.data,0);
                    clearInterval(GetObjTimerId);
                } catch (e) {}
            },15);
        }
    },0);
}
